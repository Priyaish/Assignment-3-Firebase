package com.example.movielist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private List<MovieData> movieList;
    private LayoutInflater inflater;
    private ItemClickListener clickListener;
    Button deleteButton;

    public MovieAdapter(Context context, List<MovieData> movieList, ItemClickListener clickListener) {
        this.inflater = LayoutInflater.from(context);
        this.movieList = movieList;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.movie_listrc, parent, false);
        return new MovieViewHolder(view, clickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        holder.bindData(movieList.get(position));
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    public static class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView title, studio, rating;
        //ImageView thumbnail;
        Button deleteButton = itemView.findViewById(R.id.deleteButton);

        ItemClickListener clickListener;

        public MovieViewHolder(@NonNull View itemView, ItemClickListener clickListener) {
            super(itemView);
            title = itemView.findViewById(R.id.movieTitle);
            studio = itemView.findViewById(R.id.movieStudio);
            rating = itemView.findViewById(R.id.movieRating);
          //  thumbnail = itemView.findViewById(R.id.movieThumbnail);
            this.clickListener = clickListener;
            itemView.setOnClickListener(this);
            deleteButton.setOnClickListener(v -> clickListener.onDeleteClick(getAdapterPosition()));
            }


        public void bindData(MovieData movie) {
            title.setText(movie.mtitle);
            studio.setText(movie.studio);
            rating.setText(String.valueOf(movie.rating));

        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) clickListener.onItemClick(getAdapterPosition());
        }
    }

    public interface ItemClickListener {
        void onItemClick(int position);
        void onDeleteClick(int position);
    }
}

