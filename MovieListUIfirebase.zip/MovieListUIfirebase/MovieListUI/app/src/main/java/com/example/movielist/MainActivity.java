package com.example.movielist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MovieAdapter.ItemClickListener{

    private List<MovieData> movieList = new ArrayList<>();
    private MovieAdapter adapter;
    private RecyclerView recyclerView;
    private MovieAppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MovieAdapter(this, movieList, this);
        recyclerView.setAdapter(adapter);
        Button btn = findViewById(R.id.button_add_movie);
      /*  db = Room.databaseBuilder(getApplicationContext(),
                MovieAppDatabase.class, "movie-database.db").allowMainThreadQueries().build();*/
        db = Room.databaseBuilder(getApplicationContext(),
                        MovieAppDatabase.class, "movie-database.db")
                .allowMainThreadQueries()
                .build();

        new Thread(() -> {
            List<MovieData> movies = JsonUtilityHelper.loadMoviesFromAsset(MainActivity.this, "movies.json");
            if (movies != null && !movies.isEmpty()) {
                db.movieDao().insertMovies(movies);
                movieList.clear();
                movieList.addAll(db.movieDao().getAllMovies());
                runOnUiThread(() -> adapter.notifyDataSetChanged());
            }
        }).start();

        btn.setOnClickListener(view -> {
            // Intent to start AddEditMovieActivity for a new movie
            Intent intent = new Intent(MainActivity.this, AddEditMovie.class);
            startActivity(intent);
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        new Thread(() -> {
            List<MovieData> movies = db.movieDao().getAllMovies(); // Fetch the updated list
            movieList.clear();
            movieList.addAll(movies);
            runOnUiThread(() -> adapter.notifyDataSetChanged());
        }).start();
    }

    @Override
    public void onItemClick(int position) {
        MovieData selectedMovie = movieList.get(position);
        int movieId = selectedMovie.getId();

        Intent intent = new Intent(MainActivity.this, AddEditMovie.class);
        intent.putExtra("MOVIE_ID", movieId);
        startActivity(intent);
    }
    @Override
    public void onDeleteClick(int position) {
        MovieData movie = movieList.get(position);
        new Thread(() -> db.movieDao().delete(movie)).start();
        movieList.remove(position);
        adapter.notifyItemRemoved(position);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}