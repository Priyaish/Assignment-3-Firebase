package com.example.movielist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

public class AddEditMovie extends AppCompatActivity {
    private EditText editTextTitle, editTextStudio, editTextRating;
    private Button btnSave;
    private MovieAppDatabase db;
    private MovieAdapter adapter;
    private MovieData currentMovie = null;
    private boolean isEditing = false;
    private int movieId = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_movie);

        editTextTitle = findViewById(R.id.editTextMovieTitle);
        editTextStudio = findViewById(R.id.editTextMovieStudio);
        editTextRating = findViewById(R.id.editTextMovieRating);
        btnSave = findViewById(R.id.btnsave);

        db = Room.databaseBuilder(getApplicationContext(),
                MovieAppDatabase.class, "movie-database.db").build();

        // Check if it's edit mode
        movieId = getIntent().getIntExtra("MOVIE_ID", -1);
        if (movieId != -1) {
            loadMovieData(movieId);
        }

        btnSave.setOnClickListener(v -> saveMovie());
    }

    private void loadMovieData(int movieId) {
        new Thread(() -> {
            currentMovie = db.movieDao().getMovieById(movieId);
            if (currentMovie != null) {
                runOnUiThread(() -> {
                    editTextTitle.setText(currentMovie.getMtitle());
                    editTextStudio.setText(currentMovie.getStudio());
                    editTextRating.setText(String.valueOf(currentMovie.getRating()));
                });
            }
        }).start();
    }

    private void saveMovie() {
        String title = editTextTitle.getText().toString();
        String studio = editTextStudio.getText().toString();
        float rating;
        try {
            rating = Float.parseFloat(editTextRating.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid rating format", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            MovieData movie = new MovieData(title, studio, rating);
            if (isEditing && movieId != -1) {
                movie.id = movieId;
                db.movieDao().update(movie);
            } else {
                db.movieDao().insertMovies(Arrays.asList(movie));
            }
            runOnUiThread(() -> {
                Toast.makeText(this, isEditing ? "Movie updated" : "Movie added", Toast.LENGTH_SHORT).show();
                finish(); // Exit Activity
            });
        }).start();
    }

}

