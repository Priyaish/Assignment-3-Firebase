package com.example.movielist;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "movies")
public class MovieData {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String mtitle;
    public String studio;
    public float rating;
   // public String thumbnailPath;

    public MovieData(String mtitle, String studio, float rating) {
        this.mtitle = mtitle;
        this.studio = studio;
        this.rating = rating;
       // this.thumbnailPath = thumbnailPath;
    }

    public int getId() {
        return id;
    }

    public String getMtitle() {
        return mtitle;
    }

    public String getStudio() {
        return studio;
    }

    public float getRating() {
        return rating;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setMtitle(String mtitle) {
        this.mtitle = mtitle;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public byte[] getTitle() {
    }
}
